module.exports = {
  reactStrictMode: true,
};
