// export const url = "http://192.168.252.145:3030";

export const url = "http://159.223.47.213:3030";

// export const url = "http://localhost:3030";
